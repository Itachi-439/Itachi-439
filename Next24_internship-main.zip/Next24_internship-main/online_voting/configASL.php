<?php
error_reporting(0);
$al=mysqli_connect("localhost","root","","voting_db1");
?>